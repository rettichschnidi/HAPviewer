//=======================================================================
// Stats.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_STATS_H__
#define __PCAPPP_STATS_H__ 1

#include <pcap.h>

namespace pcappp {

class PcapLive;


class Stats
{
	public:
	

		///
		///	@brief	Destroys a Stats object
		///
		~Stats();


		///
		///	@brief	Gets the number of received packets
		///
		long get_received() const
			{ return m_stat.ps_recv; }


		///
		///	@brief	Gets the number of dropped packets
		///
		long get_dropped() const
			{ return m_stat.ps_drop; }
	

		///
		/// @brief	Gets the underlying libpcap C structure
		/// @return	A pointer to the underlying struct pcap_stat
		///
		struct pcap_stat* cobj()
			{ return &m_stat; }

		///
		/// @brief	Gets the underlying libpcap C structure
		/// @return	A pointer to the underlying struct pcap_stat
		///
		struct pcap_stat const* cobj() const
			{ return &m_stat; }


	private:

		friend class PcapLive;
		
		Stats(Stats const&);
		Stats& operator=(Stats const&);

		Stats(PcapLive&);
		
		Stats& __get();

		struct pcap_stat	m_stat;
		pcap_t*				mp_pcap_t;
	
};	// class Stats
	
}	// namespace pcappp


#endif  // __PCAPPP_STATS_H__
