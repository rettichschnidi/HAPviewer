//=======================================================================
// Device.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_DEVICE_H__
#define __PCAPPP_DEVICE_H__ 1

#include <pcap++/config.h>
#include <pcap++/Address.h>
#include <vector>
#include <string>
#include <pcap.h>

namespace pcappp {


///
///	A Device object is an abstraction for any network device suitable to be
///	used to make packet capture with PcapLive
///
class Device
{
	public:

		///
		///	@brief	Creates a Device object as a copy of another
		///
		Device(Device const& device);
		

		///
		///	@brief	Assigns another Device object's contents to this one
		///
		Device &operator=(Device const& device);


		///
		///	@brief	Destroys a Device object
		///
		virtual ~Device();
	

		///
		///	@brief	Gets the name of the device
		///
		std::string const& get_name() const
			{ return m_name; }
	

		///
		///	@brief	Gets a description of the device
		///	@return	A human-readable description of the device, or an empty
		///		string ("") if a description is not available for this device
		///
		std::string const& get_description() const
			{ return m_description; }
		
		
		///
		///	@brief	Gets the addresses associated to this device
		///
		std::vector<Address> const& get_addresses() const
			{ return m_addrs; }
	
	
		///
		///	@brief	Gets all the available devices
		///
		///	Gets all the devices suitable to be used to make packet capture
		///	with PcapLive
		///
		///	@throw	PcapError
		///
		static std::vector<Device> find_all();


		///
		///	@brief	Gets a network device
		//
		///	Gets the name of a network device suitable to be used to make packet
		///	capture with PcapLive
		///
		///	@return	A string identifying the device, usable in the PcapLive
		///		constructor
		///	@throw	PcapError
		///
		static std::string lookup();


		///
		///	@brief	Returns whether the device is a loopback one
		///
		bool is_loopback() const
			{ return m_loopback; }
	

	private:
	
		Device(pcap_if_t const& iface);

		Device();

		std::string				m_name;
		std::string				m_description;
		bool					m_loopback;
		std::vector<Address>	m_addrs;
	

};	// class Device


}	// namespace pcappp


#endif	// __PCAPPP_DEVICE_H__
