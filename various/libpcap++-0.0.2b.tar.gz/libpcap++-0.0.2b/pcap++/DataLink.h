//=======================================================================
// DataLink.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_DATA_LINK_H__
#define __PCAPPP_DATA_LINK_H__ 1

#include <pcap++/config.h>
#include <pcap.h>
#include <string>

namespace pcappp {


class DataLink
{
	public:

		///
		/// @brief	Link layer type
		///
		///	See the man page of pcap(3) for more information
		///
#ifdef __cplusplus
		enum Type {
#else
		typedef enum Type {
#endif
			///	No type (used for unitialized DataLink's)
			NONE					= -1,
#ifdef DLT_APPLE_IP_OVER_IEEE1394
			///	Apple IP-over-IEEE 1394
			APPLE_IP_OVER_IEEE1394	= DLT_APPLE_IP_OVER_IEEE1394,
#endif
#ifdef DLT_AIRONET_HEADER
			///	Reserved for Aironet 802.11 cards
			AIRONET_HEADER			= DLT_AIRONET_HEADER,
#endif
#ifdef DLT_ARCNET
			///	ARCNET (Attached Resource Computer NETwork)
			ARCNET					= DLT_ARCNET,
#endif
#ifdef DLT_ARCNET_LINUX
			///	ARCNET, with no exception frames
			ARCNET_LINUX			= DLT_ARCNET_LINUX,
#endif
#ifdef DLT_A429
			///	Arinc 429
			A429					= DLT_A429,
#endif
#ifdef DLT_A653_ICM
			///	Arinc 653 Interpartition Communication
			A653_ICM				= DLT_A653_ICM,
#endif
#ifdef DLT_ATM_CLIP
			///	Linux classical IP-over-ATM
			ATM_CLIP				= DLT_ATM_CLIP,
#endif
#ifdef DLT_ATM_RFC1483
			///	RFC 1483 LLC/SNAP-encapsulated ATM
			ATM_RFC1483				= DLT_ATM_RFC1483,
#endif
#ifdef DLT_AURORA
			/// Xilinx Aurora link layer
			AURORA					= DLT_AURORA,
#endif
#ifdef DLT_AX25
			///	Amateur radio AX.25
			AX25					= DLT_AX25,
#endif
#ifdef DLT_BACNET_MS_TP
			/// BACnet MS/TP
			BACNET_MS_TP			= DLT_BACNET_MS_TP,
#endif
#ifdef DLT_BLUETOOTH_HCI_H4
			///	Bluetooth HCI UART transport layer
			BLUETOOTH_HCI_H4		= DLT_BLUETOOTH_HCI_H4,
#endif
#ifdef DLT_BLUETOOTH_HCI_H4_WITH_PHDR
			///	Bluetooth HCI UART transport layer (part H:4),
			///	with pseudo-header
			BLUETOOTH_HCI_H4_WITH_PHDR	= DLT_BLUETOOTH_HCI_H4_WITH_PHDR,
#endif
#ifdef DLT_NULL
			/// BSD loopback encapsulation (libpcap's DLT_NULL)
			BSD_LOOP				= DLT_NULL,
#endif
#ifdef DLT_CAN20B
			///	Controller Area Network (CAN) v. 2.0B
			CAN20B					= DLT_CAN20B,
#endif
#ifdef DLT_CHAOS
			///	Chaos
			CHAOS					= DLT_CHAOS,
#endif
#ifdef DLT_CISCO_IOS
			///	Cisco-internal use
			CISCO_IOS				= DLT_CISCO_IOS,
#endif
#ifdef DLT_C_HDLC
			///	Cisco PPP with HDLC framing, as per section 4.3.1 of RFC 1547
			C_HDLC					= DLT_C_HDLC,
#endif
#ifdef DLT_ECONET
			/// Acorn Econet
			ECONET					= DLT_ECONET,
#endif
#ifdef DLT_EN10MB
			/// Ethernet (10Mb, 100Mb, 1000Mb, and up)
			EN10MB					= DLT_EN10MB,
#endif
#ifdef DLT_EN3MB
			/// Experimental ethernet (3Mb)
			EN3MB					= DLT_EN3MB,
#endif
#ifdef DLT_ENC
			///	OpenBSD encapsulated IP
			ENC						= DLT_ENC,
#endif
#ifdef DLT_ERF
			///	Endace
			ERF						= DLT_ERF,
#endif
#ifdef DLT_ERF_ETH
			///	Ethernet with Endace ERF header
			ERF_ETH					= DLT_ERF_ETH,
#endif
#ifdef DLT_ERF_POS
			///	Packet-over-SONET with Endace ERF header
			ERF_POS					= DLT_ERF_POS,
#endif
#ifdef DLT_DOCSIS
			///	DOCSIS
			DOCSIS					= DLT_DOCSIS,
#endif
#ifdef DLT_FDDI
			///	FDDI (Fiber Distributed Data interface)
			FDDI					= DLT_FDDI,
#endif
#ifdef DLT_FRELAY
			///	Frame Relay
			FRELAY					= DLT_FRELAY,
#endif
#ifdef DLT_GCOM_T1E1
			///	Gcom's T1/E1 line monitoring equipment
			GCOM_T1E1				= DLT_GCOM_T1E1,
#endif
#ifdef DLT_GCOM_SERIAL
			///	Gcom's T1/E1 line monitoring equipment
			GCOM_SERIAL				= DLT_GCOM_SERIAL,
#endif
#ifdef DLT_GPF_F
			///	GPF-F
			GPF_F					= DLT_GPF_F,
#endif
#ifdef DLT_GPF_T
			///	GPF-T
			GPF_T					= DLT_GPF_T,
#endif
#ifdef DLT_GPRS_LLC
			///	GPRS LLC
			GPRS_LLC				= DLT_GPRS_LLC,
#endif
#ifdef DLT_HHDLC
			///	Siemens HiPath HDLC
			HHDLC					= DLT_HHDLC,
#endif
#ifdef DLT_IBM_SN
			/// IBM Next Federation switch
			IBM_SN					= DLT_IBM_SN,
#endif
#ifdef DLT_IBM_SP
			/// IBM SP switch
			IBM_SP					= DLT_IBM_SP,
#endif
#ifdef DLT_IEEE802
			///	IEEE 802.5 Token Ring
			IEEE802					= DLT_IEEE802,
#endif
#ifdef DLT_IEEE802_11
			///	IEEE 802.11 wireless LAN
			IEEE802_11				= DLT_IEEE802_11,
#endif
#ifdef DLT_IEEE802_11_RADIO
			///	Link-layer information followed by an 802.11 header
			IEEE802_11_RADIO		= DLT_IEEE802_11_RADIO,
#endif
#ifdef DLT_IEEE802_11_RADIO_AVS
			///	802.11 plus AVS radio information header
			IEEE802_11_RADIO_AVS	= DLT_IEEE802_11_RADIO_AVS,
#endif
#ifdef DLT_IEEE802_15_4
			///	IEEE 802.15.4, exactly as it appears in the spec
			///	(no padding, no nothing)
			IEEE802_15_4			= DLT_IEEE802_15_4,
#endif
#ifdef DLT_IEEE802_15_4_LINUX
			///	IEEE 802.15.4, with address fields padded
			IEEE802_15_4_LINUX		= DLT_IEEE802_15_4_LINUX,
#endif
#ifdef DLT_IEEE802_16_MAC_CPS
			///	IEEE 802.16 MAC Common Part Sublayer
			IEEE802_16_MAC_CPS		= DLT_IEEE802_16_MAC_CPS,
#endif
#ifdef DLT_IEEE802_16_MAC_CPS_RADIO
			///	802.16 MAC Common Part Sublayer plus a radiotap radio header
			IEEE802_16_MAC_CPS_RADIO	= DLT_IEEE802_16_MAC_CPS_RADIO,
#endif
#ifdef DLT_IP_OVER_FC
			///	IP-over-Fibre Channel, with the link-layer header being the
			///	Network_Header as described in RFC 2625
			IP_OVER_FC				= DLT_IP_OVER_FC,
#endif
#ifdef DLT_IPFILTER
        	///	Reserved for use with OpenBSD ipfilter
        	IPFILTER			= DLT_IPFILTER,
#endif
#ifdef DLT_IPMB
        	///	IPMB packet for IPMI, beginning with the I2C slave address
        	IPMB				= DLT_IPMB,
#endif
#ifdef DLT_JUNIPER_ATM1
        	///	Juniper ATM1 PIC
        	JUNIPER_ATM1			= DLT_JUNIPER_ATM1,
#endif
#ifdef DLT_JUNIPER_ATM2
        	///	Juniper ATM2 PIC
        	JUNIPER_ATM2			= DLT_JUNIPER_ATM2,
#endif
#ifdef DLT_JUNIPER_CHDLC
			///	Juniper Cisco HDLC
			JUNIPER_CHDLC			= DLT_JUNIPER_CHDLC,
#endif
#ifdef DLT_JUNIPER_ES
        	///	Juniper Encryption Services PIC
        	JUNIPER_ES				= DLT_JUNIPER_ES,
#endif
#ifdef DLT_JUNIPER_ETHER
			///	Juniper Ethernet
			JUNIPER_ETHER			= DLT_JUNIPER_ETHER,
#endif
#ifdef DLT_JUNIPER_FRELAY
			///	Juniper Frame Relay
			JUNIPER_FRELAY			= DLT_JUNIPER_FRELAY,
#endif
#ifdef DLT_JUNIPER_GGSN
        	///	Juniper GGSN PIC
        	JUNIPER_GGSN			= DLT_JUNIPER_GGSN,
#endif
#ifdef DLT_JUNIPER_ISM
			///	Juniper-private data link type
			JUNIPER_ISM				= DLT_JUNIPER_ISM,
#endif
#ifdef DLT_JUNIPER_MFR
			///	Juniper FRF.16 Frame Relay
			JUNIPER_MFR				= DLT_JUNIPER_MFR,
#endif
#ifdef DLT_JUNIPER_MLFR
			///	Juniper Multi-Link Frame Relay
			JUNIPER_MLFR			= DLT_JUNIPER_MLFR,
#endif
#ifdef DLT_JUNIPER_MLPPP
        	///	Juniper Multi-Link PPP
        	JUNIPER_MLPPP			= DLT_JUNIPER_MLPPP,
#endif
#ifdef DLT_JUNIPER_MONITOR
        	///	Juniper Passive Monitor PIC
        	JUNIPER_MONITOR			= DLT_JUNIPER_MONITOR,
#endif
#ifdef DLT_JUNIPER_PIC_PEER
			///	Juniper PIC Peer
			JUNIPER_PIC_PEER		= DLT_JUNIPER_PIC_PEER,
#endif
#ifdef DLT_JUNIPER_PPP
			///	Juniper PPP
			JUNIPER_PPP				= DLT_JUNIPER_PPP,
#endif
#ifdef DLT_JUNIPER_PPPOE
			///	Juniper PPPoE
			JUNIPER_PPPOE			= DLT_JUNIPER_PPPOE,
#endif
#ifdef DLT_JUNIPER_PPPOE_ATM
			///	Juniper PPPoE/ATM
			JUNIPER_PPPOE_ATM		= DLT_JUNIPER_PPPOE_ATM,
#endif
#ifdef DLT_JUNIPER_SERVICES
        	///	Juniper Advanced Services PIC
        	JUNIPER_SERVICES		= DLT_JUNIPER_SERVICES,
#endif
#ifdef DLT_JUNIPER_ST
        	///	Juniper-private data link type
        	JUNIPER_ST				= DLT_JUNIPER_ST,
#endif
#ifdef DLT_JUNIPER_VOICE_PIC
			///	Juniper Voice PIC
			JUNIPER_VP				= DLT_JUNIPER_VP,
#endif
#ifdef DLT_LINUX_IRDA
			///	Linux-IrDA packets, with a DLT_LINUX_SLL header followed by the
			///	IrLAP header
			LINUX_IRDA				= DLT_LINUX_IRDA,
#endif
#ifdef DLT_LINUX_LAPD
			///	LAPD (Q.921) frames, with a DLT_LINUX_SLL header captured via
			///	vISDN
			LINUX_LAPD				= DLT_LINUX_LAPD,
#endif
#ifdef DLT_LINUX_SLL
			///	Linux "cooked" capture encapsulation
			LINUX_SLL				= DLT_LINUX_SLL,
#endif
#ifdef DLT_LOOP
			///	OpenBSD loopback encapsulation
			LOOP					= DLT_LOOP,
#endif
#ifdef DLT_LTALK
			///	Apple LocalTalk. The packet begins with an AppleTalk LLAP header
			LTALK					= DLT_LTALK,
#endif
#ifdef DLT_MFR
			///	FRF.16 Frame Relay
			MFR						= DLT_MFR,
#endif
#ifdef DLT_MTP2
			///	SS7 MTP2
			MTP2					= DLT_MTP2,
#endif
#ifdef DLT_MTP2_WITH_PHDR
			///	SS7 MTP2 with Pseudo-header
			MTP2_WITH_PHDR			= DLT_MTP2_WITH_PHDR,
#endif
#ifdef DLT_MTP3
			///	SS7 MTP3
			MTP3					= DLT_MTP3,
#endif
#ifdef DLT_PCI_EXP
			/// PCI Express
			PCI_EXP					= DLT_PCI_EXP,
#endif
#ifdef DLT_PFLOG
			///	OpenBSD pflog
			PFLOG					= DLT_PFLOG,
#endif
#ifdef DLT_PPI
			///	Per Packet Information encapsulated packets
			PPI						= DLT_PPI,
#endif
#ifdef DLT_PPP
			///	PPP (Point to Point Protocol)
			PPP						= DLT_PPP,
#endif
#ifdef DLT_PPP_BSDOS
			///	BSD/OS PPP
			PPP_BSDOS				= DLT_PPP_BSDOS,
#endif
#ifdef DLT_PPP_PPPD
			///	PPP for pppd, with direction flag
			PPP_PPPD				= DLT_PPP_PPPD,
#endif
#ifdef DLT_PPP_SERIAL
			/// PPP in HDLC-like framing, as per RFC 1662, or Cisco PPP with
			///	HDLC framing, as per section 4.3.1 of RFC 1547
			PPP_SERIAL				= DLT_PPP_SERIAL,
#endif
#ifdef DLT_PPP_ETHER
			///	PPPoE (Point-to-Point Protocol over Ethernet), as per RFC 2516
			PPP_ETHER				= DLT_PPP_ETHER,
#endif
#ifdef DLT_PRISM_HEADER
			///	Prism monitor mode information followed by an 802.11 header
			PRISM_HEADER			= DLT_PRISM_HEADER,
#endif
#ifdef DLT_PRONET
			///	Proteon ProNET token ring
			PRONET					= DLT_PRONET,
#endif
#ifdef DLT_RAIF1
			RAIF1					= DLT_RAIF1,
#endif
#ifdef DLT_RAW
			/// Raw IP. The packet begins with an IP header
			RAW						= DLT_RAW,
#endif
#ifdef DLT_REDBACK_SMARTEDGE
			/// Redback SmartEdge 400/800
			REDBACK_SMARTEDGE		= DLT_REDBACK_SMARTEDGE,
#endif
#ifdef DLT_RIO
			/// RapidIO
			RIO						= DLT_RIO,
#endif
#ifdef DLT_SCCP
			/// SCCP, without pseudo-header or MTP2 or MTP3
			SCCP					= DLT_SCCP,
#endif
#ifdef DLT_SITA
			///	SITA
			SITA					= DLT_SITA,
#endif
#ifdef DLT_SLIP
			///	SLIP (Serial Line Internet Protocol)
			SLIP					= DLT_SLIP,
#endif
#ifdef DLT_SLIP_BSDOS
			///	BSD/OS SLIP
			SLIP_BSDOS				= DLT_SLIP_BSDOS,
#endif
#ifdef DLT_SUNATM
			///	SunATM devices
			SUNATM					= DLT_SUNATM,
#endif
#ifdef DLT_SYMANTEC_FIREWALL
        	///	Symantec firewall
        	SYMANTEC_FIREWALL		= DLT_SYMANTEC_FIREWALL,
#endif
#ifdef DLT_TZSP
        	///	Tazmen Sniffer Protocol
        	TZSP					= DLT_TZSP,
#endif
#ifdef DLT_USB
			///	USB packets, beginning with a USB setup header
			USB						= DLT_USB,
#endif
#ifdef DLT_USB_LINUX
			/// USB packets, beginning with a Linux USB header
			USB_LINUX				= DLT_USB_LINUX,
#endif
			///	@cond
			dirty_hack = -2
			///	@endcond
		};


		///
		///	@brief	Creates a DataLink object
		///	@param	type	The Type of the link layer, or DataLink::NONE
		///		to create an unitialized DataLink
		///
		DataLink(Type type = NONE)
		:	m_type(type) { }


		///
		///	@brief	Creates a DataLink object as a copy of another
		///
		DataLink(DataLink const& datalink)
		:	m_type(datalink.m_type) { }


		///
		///	@brief	Assign another DataLink object's contents to this one
		///
		DataLink& operator=(DataLink const& datalink)
		{
			if (this != &datalink)
				m_type = datalink.m_type;
			return *this;
		}


		///
		///	@brief	Destroys a DataLink object
		///
		~DataLink() { }


		///
		/// @brief	Gets the Type of the DataLink
		///
		Type get_type() const
			{ return m_type; }


		///
		/// @brief	Gets the description of the DataLink
		///
		std::string get_description() const
		{
			if (m_type == NONE)
				return "None (unitialized)";
			char const* desc = pcap_datalink_val_to_description(m_type);
			return desc ? desc : "Unknown";
		}


	private:

		Type	m_type;

	
};	// class DataLink


}	// namespace pcappp


#endif	// __PCAPPP_DATA_LINK_H__
