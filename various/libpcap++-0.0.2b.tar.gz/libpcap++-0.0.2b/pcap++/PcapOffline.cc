//=======================================================================
// PcapOffline.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/PcapOffline.h>
#include <pcap++/Exception.h>

namespace pcappp {


std::string STD_INPUT = "-";


PcapOffline::PcapOffline(std::string const& file_name /* = STD_INPUT */)
:
	Pcap(),
	m_filename(file_name)
{
	if (!(mp_pcap_t = pcap_open_offline(file_name.c_str(), s_ebuf)))
		throw PcapError("open_offline", s_ebuf);
}


#if HAVE_PCAP_FOPEN_OFFLINE
PcapOffline::PcapOffline(FILE* fp)
:
	Pcap(),
	m_filename()
{
	if (!(mp_pcap_t = pcap_fopen_offline(fp, s_ebuf)))
		throw PcapError("fopen_offline", s_ebuf);
}
#endif	// HAVE_PCAP_FOPEN_OFFLINE


PcapOffline::~PcapOffline()
{ }


bool PcapOffline::is_swapped() const
{
	return pcap_is_swapped(mp_pcap_t);
}


int PcapOffline::get_minor_version() const
{
	return pcap_minor_version(mp_pcap_t);
}


int PcapOffline::get_major_version() const
{
	return pcap_major_version(mp_pcap_t);
}


FILE* PcapOffline::get_file() const
{
	return pcap_file(mp_pcap_t);
}


}	// namespace pcappp
