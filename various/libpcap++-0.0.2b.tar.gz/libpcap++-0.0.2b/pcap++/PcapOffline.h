//=======================================================================
// PcapOffline.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_PCAP_OFFLINE_H__
#define __PCAPPP_PCAP_OFFLINE_H__ 1

#include <pcap++/config.h>
#include <pcap++/Pcap.h>
#include <string>


namespace pcappp {


class PcapOffline : public Pcap
{
	public:

		static std::string STD_INPUT;


		///
		/// @brief	Creates a PcapOffline to read from a savefile
		///
		/// This constructor is used to read packets from a previously created
		/// savefile.
		/// The file has the same format as those used by tcpdump and tcpslice
		///
		/// @param	file_name	The name of the file to open, or
		///		PcapOffline::STD_INPUT to read the packets from the standard
		///		input stream (stdin)
		/// @throw	PcapError
		///
		PcapOffline(std::string const& file_name = STD_INPUT);


#if HAVE_PCAP_FOPEN_OFFLINE
		///
		/// @brief	Creates a PcapOffline to read from an open stream
		/// @param	fp	The stream to read the packet data from
		/// @throw	PcapError
		///
		PcapOffline(FILE* fp);
#endif	// HAVE_PCAP_FOPEN_OFFLINE


		///
		/// @brief	Destroy a PcapOffline object
		///
		///	Closes this PcapOffline and the associated Dumper if it is open
		///
		virtual ~PcapOffline();


		///
		/// @brief	Gets the name of the input file
		///
		/// This is meaningful only when reading packets from a savefile
		///
		/// @return	The name of the savefile, or "" when reading packets from an
		///		open stream
		///
		std::string const& get_filename() const
			{ return m_filename; }


		///
		/// @brief	Gets the standard I/O input stream of the PcapOffline
		///
		/// This is meaningful only when reading packets from an open stream
		///
		/// @return	A pointer to the standard I/O stream of the PcapOffline, or
		///		NULL if reading packets from a savefile
		///
		FILE* get_file() const;

		
		///
		///	@brief	Gets the major version number of the file format of the
		///			savefile
		///
		int get_major_version() const;


		///
		///	@brief	Gets the minor version number of the file format of the
		///			savefile
		///
		int get_minor_version() const;


		///
		/// @brief	Whether the byte order of the savefile is swapped
		///
		///	@return	true if the current savefile uses a different byte order
		///		than the current system
		///
		bool is_swapped() const;


	private:

		std::string const m_filename;
	

};	// class PcapOffline


}	// namespace pcappp


#endif	// __PCAPPP_PCAP_OFFLINE_H__
