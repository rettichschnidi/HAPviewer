//=======================================================================
// Dumper.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/Dumper.h>
#include <pcap++/Pcap.h>
#include <cerrno>

namespace pcappp {


std::string Dumper::STD_OUTPUT = "-";


Dumper::Dumper(Pcap& pcap)
:
	m_pcap(pcap),
	mp_dumper_t(NULL),
	m_filename()
{ }
	
	
Dumper::~Dumper()
{
	close();
}
	

std::string const& Dumper::get_filename() const
{
	__check_open();
	return m_filename;
}


FILE* Dumper::get_file() const
{
	__check_open();
	return pcap_dump_file(mp_dumper_t);
}


void Dumper::open(std::string const& file_name /* = STD_OUTPUT */)
{
	close();
	if (!(mp_dumper_t = pcap_dump_open(m_pcap.cobj(), file_name.c_str())))
		throw PcapError("dump_open", pcap_geterr(m_pcap.cobj()));
	m_filename = file_name;
}


#if HAVE_PCAP_DUMP_FOPEN
void Dumper::open(FILE* fp)
{
	close();
	if (!(mp_dumper_t = pcap_dump_fopen(m_pcap.cobj(), fp)))
		throw PcapError("dump_fopen", pcap_geterr(m_pcap.cobj()));
}
#endif	// HAVE_PCAP_DUMP_FOPEN


void Dumper::close()
{
	if (mp_dumper_t) {
		pcap_dump_close(mp_dumper_t);
		mp_dumper_t = NULL;
	}
	m_filename.clear();
}


#if HAVE_PCAP_DUMP_FTELL
long Dumper::ftell() const
{
	__check_open();
	long ret = pcap_dump_ftell(mp_dumper_t);
	if (ret >= 0)
		return ret;
	else
		throw PcapError("dump_ftell", pcap_strerror(errno));
}
#endif	// HAVE_PCAP_DUMP_FTELL


void Dumper::flush()
{
	__check_open();
	if (pcap_dump_flush(mp_dumper_t) < 0)
		throw PcapError("dump_flush", pcap_strerror(errno));
}


}	// namespace pcappp
