//=======================================================================
// Pcap.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_PCAP_H__
#define __PCAPPP_PCAP_H__ 1

#include "pcap++/config.h"
#include <pcap++/Packet.h>
#include <pcap++/DataLink.h>
#include <pcap.h>
#include <vector>
#include <string>


namespace pcappp {

class Dumper;


///
/// This class wraps the libpcap's C structure pcap_t, and it is the main class
/// to perform packet capture with libpcap++.
///
class Pcap
{
	public:

		///
		/// @brief	32 bit integer representing a IPv4 netmask
		///
		typedef bpf_u_int32 Netmask;

		static const int OK				= 1;
		static const int BREAKLOOP		= -2;
		static const int LOOP_FOREVER	= -1;
		static const int DISPATCH_ALL	= -1;


		///
		/// @brief	Type of callback used in loop() and dispatch().
		///
		/// A Handler specifies a callback which is called for each incoming packet,
		/// with two arguments: a reference to the Pcap from which loop() or
		///	dispatch() has been called, and a reference to the current packet.
		///
		/// Note that at the time the handler is invoked, only the first
		/// packet.get_caplen() bytes are available, which won’t necessarily be the
		///	entire packet; to capture the entire packet, a sufficiently large caplen
		/// has to be provided in the Pcap constructor (a value of 65535 should be
		/// sufficient on most if not all networks).
		///
		///	Note also that the payload of the incoming Packet (accessible by
		///	packet.get_data()), is owned by libpcap. This means that care has
		///	to be taken when manipulating the data: If you want it to be
		///	persistent among successive incoming packets, create a new Packet
		///	object as a copy of the incoming one, and then call Packet::manage()
		///	on it
		///
		typedef void (*Handler) (Pcap& pcap, Packet const& packet);
	
		
		///
		/// @brief	Collect and process packets.
		/// @param	handler	The callback to be called for each incoming packet
		/// @param	cnt	 The maximum number of packets to process before returning.
		///		For PcapLive only one bufferful of packets is read at a time, so fewer
		///		than cnt packets may be processed. A cnt of Pcap::DISPATCH_ALL processes
		///		all the packets received in one buffer on PcapLive, or all
		///		the packets in the savefile on PcapOffline.
		/// @return	The number of packets read. On PcapLive, 0 may be returned if
		///		no packets were read from the interface (if, for example, they were
		///		discarded because they didn’t pass the packet filter, or if, on
		///		platforms that support a read timeout that starts before any packets
		///		arrive, the timeout expires before any packets arrive, or if the
		///		PcapLive is in non-blocking mode and no packets were available to be
		///		read). On PcapOffline, 0 may be returned if no more packets are
		///		available in the savefile. A return of Pcap::BREAKLOOP indicates that
		///		the loop terminated due to a call to breakloop() before any packets
		///		were processed.
		///
		/// Note that on PcapLive, dispatch() will not necessarily return when
		/// the read times out; on some platforms, the read timeout isn’t supported,
		/// and, on other platforms, the timer doesn’t start until at least one
		/// packet arrives. This means that the read timeout should not be used in,
		/// for example, an interactive application, to allow the packet capture
		/// loop to "poll" for user input periodically, as there’s no guarantee that
		/// dispatch() will return after the timeout expires.
		///
		/// @throw	PcapError
		///
		int dispatch(Handler handler, int cnt = Pcap::DISPATCH_ALL);


		///
		/// @brief	Collect and process packets.
		///
		/// Similar to dispatch() except it keeps reading packets until cnt packets
		/// are processed or an error occurs.
		///
		/// @param	handler	The callback to be called for each incoming packet
		/// @param	cnt	Maximum number of packets to process. A value of
		///		Pcap::LOOP_FOREVER causes loop() to loop forever (or at least
		///		until an error occurs).
		/// @return	Pcap::OK upon successful processing of all the cnt packets, or
		///		Pcap::BREAKLOOP if the loop terminated due to a call to
		///		breakloop() before any packets were processed.
		/// @throw	PcapError
		///
		int loop(Handler handler, int cnt = Pcap::LOOP_FOREVER);


		///
		///	@brief	Reads the next packet available from the interface or
		///		the savefile
		///	@param	packet A reference to a Packet that will be filled with the
		///		data of the incoming packet upon successful read
		///	@return	true if a packet was successfully read
		///
		///	In PcapLive, the read may fail if the timeout expires before any
		///	packet is captured. In PcapOffline, the read may if the end-of-file
		///	of the savefile is reached.@n
		///	In both cases, a flag is set in the Pcap so that ok() and the
		///	operator bool() return false. This flag is cleared upon each
		///	successful read
		///
		///	@throw	PcapError
		///	
		bool next(Packet& packet)
			{ return (*this >> packet); }


		///
		///	@brief	Stop reading packets
		///
		/// Sets a flag that will force dispatch() or loop() to return rather than
		/// looping. They will return the number of packets that have been processed
		///	so far, or Pcap::BREAKLOOP if no packets have been processed so far.
		///
		///	This function is safe to use inside a signal handler on UNIX or a console
		///	control handler on Windows, as it merely sets a flag that is checked
		///	within the loop.
		/// The flag is checked in loops reading packets from the OS - a signal by
		///	itself will not necessarily terminate those loops - as well as in loops
		///	processing a set of packets returned by the OS. Note that if you are
		///	catching signals on UNIX systems that support restarting system calls
	    ///	after a signal, and calling breakloop() in the signal handler, you must
		///	specify, when catching those signals, that system calls should NOT be
		///	restarted by that signal. Otherwise, if the signal interrupted a call
		///	reading packets in a PcapLive, when your signal handler returns
		///	after calling breakloop(), the call will be restarted, and the loop will
		///	not terminate until more packets arrive and the call completes.
		///
    	///	Note also that, in a multi-threaded application, if one thread is blocked
		///	in dispatch(), loop() or  next(), a call to breakloop() in a different
		///	thread will not unblock that thread; you will need to use whatever
		///	mechanism the OS provides for breaking a thread out of blocking calls in
		///	order to unblock the thread, such as thread cancellation in systems that
		///	support POSIX threads.
		///
		///	Note that next() will, on some platforms, loop reading packets from the
		///	OS; that loop will not necessarily be terminated by a signal, so
		///	breakloop() should be used to terminate packet processing even if next()
		///	is being used.
		///
		///	breakloop() does not guarantee that no further packets will be processed
		///	by dispatch() or loop() after it is called; at most one more packet might
		///	be processed.
		///
		///	If Pcap::BREAKLOOP is returned from dispatch() or loop(), the flag is
		///	cleared, so a subsequent call will resume reading packets. If a positive
		///	number is returned, the flag is not cleared, so a subsequent call will
		///	return Pcap::BREAKLOOP and clear the flag.
		///
		void breakloop();

	
		///
		/// @brief	Gets the Dumper object associated with this Pcap
		///
		/// Every Pcap has an attached Dumper object, which may be opened,
		/// closed or manipulated using the Dumper member functions
		///
		/// @return	A reference to the Dumper object
		///
		Dumper& get_dumper()
			{ return *mp_dumper; }

		///
		/// @brief	Gets the Dumper object associated with this Pcap
		///
		/// Every Pcap has an attached Dumper object, which may be opened,
		/// closed or manipulated using the Dumper member functions.
		///
		/// @return	A const reference to the Dumper object
		///
		Dumper const& get_dumper() const
			{ return *mp_dumper; }


		///
		/// @brief	Gets the underlying libpcap C structure
		/// @return	A pointer to the underlying pcap_t
		///
		pcap_t* cobj()
			{ return mp_pcap_t; }

		///
		/// @brief	Gets the underlying libpcap C structure
		/// @return	A pointer to the underlying pcap_t
		///
		pcap_t const* cobj() const
			{ return mp_pcap_t; }


		///
		///	@brief	Sets the link layer type
		///
		void set_datalink(DataLink const& datalink);


		///
		///	@brief	Gets the link layer type
		///
		DataLink get_datalink() const;


		///
		///	@brief	Gets all supported DataLinks
		///
		///	Gets a list of all the supported data link types of the interface
		///	associated with this Pcap
		///
		///	@return	A std::vector containing the DataLinks
		///
		std::vector<DataLink> list_datalinks() const;


		///
		/// @brief	Gets the snaplen.
		///
		unsigned int get_snaplen() const;


		///
		/// @brief	Gets the BPF filter expression applied to the Pcap.
		///	@return	The filter expression, or an empty string if no filter is
		///		currently applied to the Pcap.
		///
		std::string const& get_filter() const
			{ return m_filter; }


		///
		///	@brief	Apply a filter given by a BPF expression
		///	@param	expression	The filter expression
		///	@param	optimize	Whether optimization on the resulting code is
		///		performed
		///	@param	netmask		Specifies the IPv4 netmask of the network on
		///		which packets are being captured. It is used only when checking
		///		for IPv4 broadcast addresses in the filter program. If the
		///		netmask of the network on which packets are being captured isn’t
       	///		known to the program, or if packets are being captured on the
		///		Linux "any" pseudo-interface that can capture on more than one
		///		network, a value of 0 can be supplied; tests for IPv4 broadcast
       	///		addresses won’t be done correctly, but all other tests in the
		///		filter program will be OK
		///	@throw	PcapError
		///
		void set_filter(std::string const& expression,
						bool optimize		= false,
						Netmask netmask		= 0);

	
		///
		/// @brief	Reads the next packet available from the interface or the
		///		savefile
		///
		///	In PcapLive, the read may fail if the timeout expires before any
		///	packet is captured. In PcapOffline, the read may if the end-of-file
		///	of the savefile is reached.@n
		///	In both cases, a flag is set in the Pcap so that ok() and the
		///	operator bool() return false. This flag is cleared upon each
		///	successful read
		///
		/// @throw	PcapError
		///
		friend Pcap& operator>>(Pcap& pcap, Packet& packet);
		
		
		///
		///	@brief	Gets the read state of the Pcap
		///	@return	true if the last attempt to read a packet was successful,
		///		and false otherwise
		///
		bool ok() const
			{ return m_ok; }


		///
		///	@brief	Gets the read state of the Pcap
		///	@return	true if the last attempt to read a packet was successful,
		///		and false otherwise
		///
		operator bool() const
			{ return m_ok; }


	protected:

		Pcap();
		virtual ~Pcap();

		std::string geterr() const;

		///@cond
		static char	s_ebuf[];
		pcap_t*		mp_pcap_t;
		///@endcond


	private:

		typedef int (*__pcap_read_func)(pcap_t*, int, pcap_handler, u_char*);

		int __read_packets(int, Handler, __pcap_read_func);
		
		static void __handler(	u_char* user,
								struct pcap_pkthdr const* header,
								u_char const* data)
		{
			Pcap* pcap = reinterpret_cast<Pcap*>(user);
			(pcap->m_handler)(*pcap, Packet(*header, data));
		}

		// Forbid copies
		Pcap(Pcap const&);
		Pcap& operator=(Pcap const&);	

		Dumper*		mp_dumper;
		Handler		m_handler;
		bool		m_ok;
		std::string	m_filter;

};	// class Pcap


}	// namespace pcappp


#endif	// __PCAPPP_PCAP_H__
