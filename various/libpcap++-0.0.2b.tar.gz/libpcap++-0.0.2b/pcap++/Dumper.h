//=======================================================================
// Dumper.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_DUMPER_H__
#define __PCAPPP_DUMPER_H__ 1

#include <pcap++/config.h>
#include <pcap++/Packet.h>
#include <pcap++/Exception.h>	// DumperClosed
#include <pcap.h>
#include <string>


namespace pcappp {

class Pcap;


class Dumper
{
	public:

		static std::string STD_OUTPUT;


		///
		/// @brief	Open a Dumper to write packets to a savefile
		///
		/// If the Dumper is already open, the old savefile or stream is
		///	closed, and the Dumper is open again
		///
		/// @param	filename The name of the savefile, or Dumper::STD_OUTPUT to
		///		write the packets to the standard output stream (stdout)
		/// @throw	PcapError
		///
		void open(std::string const& filename = STD_OUTPUT);


#if HAVE_PCAP_DUMP_FOPEN
		///
		/// @brief	Open a Dumper to write packets to an open stream
		///
		/// If the Dumper is already open, the old savefile or stream is
		///	closed, and the Dumper is open again
		///
		/// @param	stream The stream, which must be open for writing
		/// @throw	PcapError
		///
		void open(FILE* stream);
#endif	// HAVE_PCAP_DUMP_FOPEN

		
		///
		/// @brief	Closes the savefile or the stream associated with the Dumper
		///
		/// If the Dumper is already closed, it has no effect
		///
		void close();

		
		///
		/// @brief	Gets the name of the current savefile
		/// @return	The name of the savefile, or an empty string if writing
		///		packets to a stream
		/// @throw	DumperClosed
		///
		std::string const& get_filename() const;


		///
		/// @brief	Gets the current standard I/O stream of the savefile
		/// @throw	DumperClosed
		///
		FILE* get_file() const;


		///
		/// @brief	Get the underlying libpcap C structure
		/// @return	A pointer to the underlying pcap_dumper_t
		///
		pcap_dumper_t* cobj()
			{ return mp_dumper_t; }

		///
		/// @brief	Get the underlying libpcap C structure
		/// @return	A const pointer to the underlying pcap_dumper_t
		///
		pcap_dumper_t const* cobj() const
			{ return mp_dumper_t; }


		///
		/// @brief	Flushes the output buffer
		///
		///	Flushes the output buffer to the savefile, so that any packets written
	    ///	with dump() but not yet written to the savefile will be written
	    ///
		/// @throw	PcapError, DumperClosed
		///
		void flush();


#if HAVE_PCAP_DUMP_FTELL
		///
		/// @brief	Gets the current file position
		///	@return	The current file position for the savefile, representing the
		///		number of bytes written so far
		///	@throw	PcapError, DumperClosed
		///	
		long ftell() const;
#endif	// HAVE_PCAP_DUMP_FTELL


		///
		/// @brief	Writes a packet to the savefile
		/// @throw	DumperClosed
		///	
		void dump(Packet const& packet)
		{
			__check_open();
			pcap_dump(reinterpret_cast<u_char*>(mp_dumper_t),
				&packet.get_header(), packet.get_data());
		}

		
		///
		///	@brief	Gets the status of the Dumper
		/// @return	Whether the Dumper is currently open
		///
		bool is_open() const
			{ return mp_dumper_t != NULL; }


		///
		/// @brief	An alias for is_open()
		///
		operator bool() const
			{ return is_open(); }


		///
		/// @brief	Writes a packet to the savefile (like dump())
		/// @throw	DumperClosed
		///
		friend Dumper& operator<<(Dumper& dumper, Packet const& packet)
		{
			dumper.dump(packet);
			return dumper;
		}
		
		
	private:
	
		friend class Pcap;

		Dumper(Pcap& pcap);

		// Prevent copies
		Dumper(Dumper&);
		Dumper& operator=(Dumper&);

		~Dumper();

		void __check_open() const
		{
			if (!is_open())
				throw DumperClosed();
		}

		Pcap&			m_pcap;
		pcap_dumper_t*	mp_dumper_t;
		std::string		m_filename;


};	// class Dumper

}	// namespace pcappp


#endif  // __PCAPPP_DUMPER_H__

