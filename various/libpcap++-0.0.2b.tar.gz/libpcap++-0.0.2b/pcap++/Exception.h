//=======================================================================
// Exception.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_EXCEPTION_H__
#define __PCAPPP_EXCEPTION_H__ 1

#include <pcap++/config.h>
#include <string>
#include <stdexcept>


namespace pcappp {


///
/// Generic exception thrown by libpcap++.@n
///	Derives from std::runtime_error, so one can call what() on it in order
///	to get a human readable error message.
///
class Exception : public std::runtime_error
{
	public:

		///
		/// @brief	Creates an Exception object
		///	@param	msg	The error message
		///
		Exception(std::string const& msg = "")
		:	std::runtime_error(msg) { }

};


///
///	Exception thrown whenever an error occurs in a call to a function of
///	libpcap
///
class PcapError : public Exception
{
	public:
	
		///
		/// @brief	Creates a PcapError object
		///	@param	pcap_func	The libpcap function that originated the error
		///		(without the leading "pcap_" and the parenthesis)
		///	@param	msg	The error message
		///
		PcapError(std::string const& pcap_func, std::string const& msg = "")
		:	Exception(std::string("pcap_") + pcap_func + "()"
						+ (msg.empty() ? "" : ": ") + msg)
		{ }
};


///
/// This exception is thrown by libpcap++ whenever a Dumper's member function
/// is called which requires the Dumper object to be open, but the Dumper
///	object is closed
///
class DumperClosed : public Exception { };


}	// namespace pcappp


#endif	// __PCAPPP_EXCEPTION_H__
