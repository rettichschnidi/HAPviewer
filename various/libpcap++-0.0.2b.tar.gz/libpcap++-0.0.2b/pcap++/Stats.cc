//=======================================================================
// Stats.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/config.h>
#include <pcap++/PcapLive.h>
#include <pcap++/Exception.h>
#include <pcap++/Stats.h>


namespace pcappp
{


Stats::Stats(PcapLive& live)
:
	m_stat(),
	mp_pcap_t(live.cobj())
{ }


Stats::~Stats()
{ }


Stats& Stats::__get()
{
	if (pcap_stats(mp_pcap_t, &m_stat) < 0)
		throw PcapError("stats", pcap_geterr(mp_pcap_t));
	return *this;
}


}	// namespace pcappp
