//=======================================================================
// Device.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/Device.h>
#include <pcap++/Exception.h>

namespace pcappp {


Device::Device(pcap_if_t const& iface)
:
	m_name(iface.name ? iface.name : ""),
	m_description(iface.description ? iface.description : ""),
	m_loopback(iface.flags & PCAP_IF_LOOPBACK),
	m_addrs()
{
	for (pcap_addr_t* a = iface.addresses; a; a = a->next)
		m_addrs.push_back(*a);
}


Device::Device(Device const& dev)
:
	m_name(dev.m_name),
	m_description(dev.m_description),
	m_loopback(dev.m_loopback),
	m_addrs(dev.m_addrs)
{ }


Device::Device()
:
	m_name(),
	m_description(),
	m_loopback(),
	m_addrs()
{ }


Device::~Device()
{ }


Device& Device::operator=(Device const& dev)
{
	if (this != &dev) {
		m_name = dev.m_name;
		m_description = dev.m_description;
		m_loopback = dev.m_loopback;
		m_addrs = dev.m_addrs;
	}
	return *this;
}


// [static]
std::vector<Device> Device::find_all()
{
	pcap_if_t* ifs;
	char ebuf[PCAP_ERRBUF_SIZE + 1];

	if (pcap_findalldevs(&ifs, ebuf) < 0)
		throw PcapError("findalldevs", ebuf);
	
	std::vector<Device> devs;

	for (pcap_if_t* i = ifs; i; i = i->next)
		devs.push_back(*i);
	
	pcap_freealldevs(ifs);
	
	return devs;
}


// [static]
std::string Device::lookup()
{
	char ebuf[PCAP_ERRBUF_SIZE + 1];
	char* dev = pcap_lookupdev(ebuf);
	if (!dev)
		throw PcapError("lookupdev", ebuf);
	return dev;
}


}	// namespace pcappp
