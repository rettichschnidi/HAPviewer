//=======================================================================
// Packet.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/Packet.h>

extern "C" {
	#include <string.h>	// memset(), memcpy()
	#include <stdlib.h>	// malloc()
}

namespace pcappp {


Packet::Packet()
:
	m_header(),
	mp_data(NULL),
	m_managed(false)
{
	memset(&m_header, 0, sizeof(m_header));
}


Packet::Packet(Data const* data, Length length)
:
	m_header(),
	mp_data(const_cast<Data*>(data)),
	m_managed(false)
{
	memset(&(m_header.ts), 0, sizeof(m_header.ts));
	m_header.len = m_header.caplen = length;
}


// [virtual]
Packet::~Packet()
{
	if (m_managed && mp_data) {
		free(reinterpret_cast<void*>(mp_data));
		mp_data = NULL;
	}
}


void Packet::manage()
{
	if (m_managed || mp_data == NULL)
		return;
	void* dest = malloc(m_header.caplen);	//XXX error?
	memcpy(dest, __get_void_const_p(), m_header.caplen);
	mp_data = reinterpret_cast<Data*>(dest);
	m_managed = true;
}


void const* Packet::__get_void_const_p()
{
	void* p = reinterpret_cast<void*>(mp_data);
	return const_cast<void const*>(p);
}


}	// namespace pcappp

