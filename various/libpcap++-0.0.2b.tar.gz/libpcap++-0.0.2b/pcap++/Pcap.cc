//=======================================================================
// Pcap.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/Pcap.h>
#include <pcap++/Dumper.h>
#include <pcap++/Exception.h>
#include <cassert>
#include <cstdlib>

namespace pcappp {


///@cond
char Pcap::s_ebuf[PCAP_ERRBUF_SIZE + 1] = "";
///@endcond

Pcap::Pcap()
:
	mp_pcap_t(NULL),
	mp_dumper(NULL),
	m_handler(NULL),
	m_ok(true),
	m_filter()
{
	mp_dumper = new Dumper(*this);
}


Pcap::~Pcap()
{
	if (mp_pcap_t)
		pcap_close(mp_pcap_t);
	delete mp_dumper;
}


unsigned int Pcap::get_snaplen() const
{
	assert(mp_pcap_t != NULL);
	return pcap_snapshot(mp_pcap_t);
}


void Pcap::breakloop()
{
	assert(mp_pcap_t != NULL);
	pcap_breakloop(mp_pcap_t);
}


DataLink Pcap::get_datalink() const
{
	assert(mp_pcap_t != NULL);
	return DataLink(static_cast<DataLink::Type>(pcap_datalink(mp_pcap_t)));
}


void Pcap::set_datalink(DataLink const& datalink)
{
	assert(mp_pcap_t != NULL);
	if (pcap_set_datalink(mp_pcap_t, datalink.get_type()) < 0)
		throw PcapError("set_datalink");
}


std::vector<DataLink> Pcap::list_datalinks() const
{
	assert(mp_pcap_t != NULL);

	int* types;
	int n_types = pcap_list_datalinks(mp_pcap_t, &types);
	if (n_types < 0)
		throw PcapError("list_datalinks");

	std::vector<DataLink> datalinks;
	for (int i = 0; i < n_types; ++i)
		datalinks.push_back(DataLink(static_cast<DataLink::Type>(types[i])));
	
	free(types);
	
	return datalinks;
}


int Pcap::dispatch(Handler handler, int cnt /* = DISPATCH_ALL */)
{
	return __read_packets(cnt, handler, pcap_dispatch);
}


int Pcap::loop(Handler handler, int cnt /* = LOOP_FOREVER */)
{
	return (__read_packets(cnt, handler, pcap_loop) == 0) ? OK : BREAKLOOP;
}


void Pcap::set_filter(	std::string const& expression,
						bool optimize,		// = false
						Netmask netmask)	// = 0
{
	assert(mp_pcap_t != NULL);
	
	struct bpf_program bpf;

#if PCAP_COMPILE_USE_CONST_CHAR
	int ret = pcap_compile(mp_pcap_t, &bpf,
		expression.c_str(), optimize, netmask);
#else
	int ret = pcap_compile(mp_pcap_t, &bpf,
		const_cast<char*>(expression.c_str()), optimize, netmask);
#endif
	if (ret < 0)
		throw PcapError("compile", geterr());

	if (pcap_setfilter(mp_pcap_t, &bpf) < 0)
		throw PcapError("setfilter", geterr());
	
	pcap_freecode(&bpf);

	m_filter = expression;
}


// [friend]
Pcap& operator>>(Pcap& p, Packet& packet)
{
	static struct pcap_pkthdr* header;
	static u_char const* data;

	switch (pcap_next_ex(p.mp_pcap_t, &header, &data)) {
		case 1:		// ok
			packet = Packet(*header, data);
			p.m_ok = true;
			break;
		case -1:	// error
			throw PcapError("next_ex", p.geterr());
		default:	// EOF or timeout expired
			p.m_ok = false;
	}
	return p;
}


std::string Pcap::geterr() const
{
	assert(mp_pcap_t != NULL);
	return pcap_geterr(mp_pcap_t);
}


int Pcap::__read_packets(int cnt, Handler handler, __pcap_read_func f)
{
	assert(mp_pcap_t != NULL);
	assert(handler != NULL);

	m_handler = handler;

	int ret = (f)(mp_pcap_t, cnt, __handler, reinterpret_cast<u_char*>(this));
	if (ret == -1)
		throw PcapError((f == pcap_loop ? "loop" : "dispatch"), geterr());
	
	return ret;
}


}	// namespace pcappp
