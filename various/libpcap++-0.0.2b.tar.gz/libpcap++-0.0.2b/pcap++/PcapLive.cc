//=======================================================================
// PcapLive.cc
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#include <pcap++/PcapLive.h>
#include <pcap++/Exception.h>
#include <pcap++/Stats.h>

namespace pcappp {


PcapLive::PcapLive(	std::string const& dev,
					unsigned int len,		// = MAX_SNAPLEN
					bool promisc,			// = true
					unsigned int to_ms)		// = 0
:
	Pcap(),
	m_timeout(to_ms),
	m_promiscuous(promisc),
	m_device(dev.empty() ? "any" : dev),
#if HAVE_PCAP_DIRECTION_T
	m_direction(IN_OUT),
#endif
	mp_stats(NULL)
{
	if (!(mp_pcap_t = pcap_open_live(dev.c_str(), len, promisc, to_ms, s_ebuf)))
		throw PcapError("open_live", s_ebuf);
	mp_stats = new Stats(*this);
}


// [virtual]
PcapLive::~PcapLive()
{
	delete mp_stats;
}


#if HAVE_PCAP_DIRECTION_T
void PcapLive::set_direction(Direction dir)
{
	if (pcap_setdirection(mp_pcap_t, static_cast<pcap_direction_t>(dir)) < 0)
		throw PcapError("setdirection");
	m_direction = dir;
}
#endif	// HAVE_PCAP_DIRECTION_T


void PcapLive::set_nonblock(bool set /* = true */)
{
	if (pcap_setnonblock(mp_pcap_t, set, s_ebuf) < 0)
		throw PcapError("setnonblock", s_ebuf);
}


bool PcapLive::is_nonblock()
{
	int nb = pcap_getnonblock(mp_pcap_t, s_ebuf);
	if (nb < 0)
		throw PcapError("getnonblock", s_ebuf);
	return nb;
}


#if HAVE_PCAP_INJECT
void PcapLive::inject(Packet const& packet)
{
	if (pcap_inject(mp_pcap_t, packet.get_data(), packet.get_length()) < 0)
		throw PcapError("inject", geterr());
}


// [friend]
PcapLive& operator<<(PcapLive& pcap, Packet const& packet)
{
	pcap.inject(packet);
	return pcap;
}
#endif	// HAVE_PCAP_INJECT


Stats const& PcapLive::get_stats()
{
	return mp_stats->__get();
}


int PcapLive::get_fd() const
{
	return pcap_fileno(mp_pcap_t);
}


int PcapLive::get_selectable_fd() const
{
	return pcap_get_selectable_fd(mp_pcap_t);
}


}	// namespace pcappp
