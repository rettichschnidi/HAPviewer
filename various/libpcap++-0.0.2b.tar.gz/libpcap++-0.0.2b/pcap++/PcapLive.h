//=======================================================================
// PcapLive.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_PCAP_LIVE_H__
#define __PCAPPP_PCAP_LIVE_H__ 1

#include <pcap++/config.h>
#include <pcap++/Pcap.h>


namespace pcappp {

class Stats;


///
/// A PcapLive is a Pcap suitable for live capture. This means that the packets
///	are read from a network interface.
///	Note that on some platforms, this may require special privileges.
///	
class PcapLive : public Pcap
{
	public:

		///
		/// @brief	Default snap length for PcapLive()
		///
		static unsigned int const MAX_SNAPLEN = 65535;

	
#if HAVE_PCAP_DIRECTION_T
		///
		///	@brief	Type of direction the packets will be captured
		///
		typedef enum {
			/// Packets received by the device
			IN		= PCAP_D_IN,
			/// Packets sent by the device
			OUT		= PCAP_D_OUT,
			///	Packets received or sent by the device
			IN_OUT	= PCAP_D_INOUT
		} Direction;
#endif	// HAVE_PCAP_DIRECTION_T


		///
		/// @brief	Creates a PcapLive object
		/// @param	device	A string identifying the network device to open
		///		(e.g. "eth0"). On Linux systems with 2.2 or later kernels, a
		///		device string of "any" or "" (empty) can be used to capture
		///		packets from all interfaces
		/// @param	snaplen	The maximum	number of bytes to capture. If this value is
		///		less than the size of a packet that is captured, only the first
		///		snaplen bytes of that packet will be provided as packet data. The
		///		default value of PcapLive::MAX_SNAPLEN should be sufficient, on
		///		most if not all networks, to capture all the data available from
		///		the packet
		/// @param	promisc	Whether the interface is to be put into promiscuous
		///		mode. (Note that even if this parameter is false, the interface
		///		could well be in promiscuous mode for some other reason.) For
		///		now, this doesn’t work on the "any" device; if an argument of
		///		"any" or empty is supplied, the promisc parameter is ignored
		/// @param	timeout_ms	The read timeout, in miliseconds. It is used to arrange
		///		that the read not necessarily returns immediately when a packet
		///		is seen, but that it waits for some amount of time to allow more
		///		packets to arrive and to read multiple packets from the OS
		///		kernel in one operation. Not all platforms support a read
		///		timeout; on platforms that don’t, the read timeout is ignored. A
		///		timeout of zero, on platforms that support a read timeout, will
		///		cause a read to wait forever to allow enough packets to arrive,
		///		with no timeout
		/// @throw	PcapError
		///
		PcapLive(	std::string const& device,
					unsigned int snaplen	= MAX_SNAPLEN,
					bool promisc			= true,
					unsigned int timeout_ms	= 0);
	
	
		///
		/// @brief	Destroys the PcapLive object
		///
		virtual ~PcapLive();


#if HAVE_PCAP_INJECT
		///
		///	@brief	Sends a raw packet through the network interface
		///	
		///	Note that, even if you successfully open the network interface,
		///	you  might not have permission to send packets on it, or it might
		///	not support sending packets; as the PcapLive constructor doesn’t
		///	have a flag to indicate whether to open for  capturing, sending, or
		///	capturing and sending, you cannot request a PcapLive that supports
		///	sending and be notified at construction time whether sending will be
		///	possible.@n
		///	Note also that some devices might not support sending packets.@n
		///	@n
		///	On some platforms, the link-layer header of the packet that’s sent
		///	might not be the same as the link-layer header of the packet
		///	supplied to inject(), as the source link-layer address, if the
		///	header contains such an address, might be changed to be the address
		///	assigned to the interface on which the packet it sent, if the
		///	platform doesn’t support sending completely raw and unchanged
		///	packets. Even worse, some drivers on some platforms might change the
		///	link-layer type field to whatever value libpcap used when attaching
		///	to the device, even on platforms that do nominally support sending
		///	completely raw and unchanged packets.	
		///
		///	@param	packet	The Packet to be sent
		///	@throw	PcapError
		///
		void inject(Packet const& packet);


		///
		///	@brief	An alias for inject()
		///	@param	pcap	The PcapLive object
		///	@param	packet	The Packet to be sent
		///	@throw	PcapError
		///
		friend PcapLive& operator<<(PcapLive& pcap, Packet const& packet);
#endif	// HAVE_PCAP_INJECT


		///
		/// @brief	Gets the current non-blocking state
		/// @return	Whether the capture is on non-blocking mode
		/// @throw	PcapError
		///
		bool is_nonblock();


		///
		/// @brief	Gets the timeout, in miliseconds
		///
		int get_timeout() const
			{ return m_timeout; }


		///
		/// @brief	Gets the promiscuous state of the interface.
		/// @return	Whether the interface is put in promiscuous mode.
		///
		bool is_promiscuous() const
			{ return m_promiscuous; }


		///
		/// @brief	Gets the name of the device
		///
		std::string const& get_device() const
			{ return m_device; }

		
		///
		/// @brief	Gets the file descriptor number from which captured packets
		///		are read
		///
		int get_fd() const;

		
		///
		/// @brief	Gets the selectable file descriptor number
		/// @return	On UNIX, a file descriptor number for a file descriptor on
		///		which one can do a select() or poll() to wait for it to be
		///		possible to read packets without blocking, if such a descriptor
		///		exists, or -1, if no such descriptor exists.
		///		Some network devices do not support select() or poll() (for example,
		///		regular network devices on FreeBSD 4.3 and 4.4, and Endace DAG
		///		devices), so -1 is returned for those devices.
		///
 		/// Note that on most versions of most BSDs (including MacOS X) select()
		///	and poll() do not work correctly on BPF devices; get_selectable_fd()
		///	will return a file descriptor on most of those versions (the
		///	exceptions being FreeBSD 4.3 and 4.4), a simple select() or poll()
		///	will not return even after a timeout specified in open() expires.
		///	To work around this, an application that uses select() or poll() to
		///	wait for packets to arrive must put the PcapLive in non-blocking
		///	mode, and must arrange that the select() or poll() have a timeout
		///	less than or equal to the timeout specified in open(), and must try
		///	to read packets after that timeout expires, regardless of whether
		///	select() or poll() indicated that the file descriptor for the
		///	PcapLive is ready to be read or not. (That workaround will not work
		///	in FreeBSD 4.3 and later; however, in FreeBSD 4.6 and later,
		///	select() and poll() work correctly on BPF devices, so the workaround
		///	isn’t necessary, although it does no harm)
		///
		int get_selectable_fd() const;


		///
		///	@brief	Gets packet statistics
		///	@return	A Stats object containing the packet statistics from the
		///		start of the capture to the time of the call
		///	@throw	PcapError
		///
		Stats const& get_stats();


#if HAVE_PCAP_DIRECTION_T
		///
		///	@brief	Gets the direction of the capture
		///
		Direction get_direction() const
			{ return m_direction; }


		///
		///	@brief	Specifies a direction that packets will be captured
		///
		///	In some platforms changing the direction of the capture might not be
		///	supported. In some other platforms the direction cannot be set to
		///	PcapLive::OUT. In both cases a PcapError exception is thrown.@n
		///	The default setting is PcapLive::IN_OUT
		///
		///	@throw	PcapError
		///
		void set_direction(Direction direction);
#endif	// HAVE_PCAP_DIRECTION_T

		
		///
		/// @brief	Puts the PcapLive into non-blocking mode, or takes it out of
		///		non-blocking mode.
		///
		/// In non-blocking mode, an attempt to read from the network interface with
		/// dispatch() will, if no packets are currently available to be read,
		/// return immediately rather than blocking waiting for packets to arrive.
		/// Note that loop() and next() will not work in non-blocking mode.
		///
		/// @param	set	Whether the PcapLive is to be put into non-blocking mode
		/// @throw	PcapError
		///
		void set_nonblock(bool set = true);


	private:

		PcapLive(PcapLive const&);
		PcapLive& operator=(PcapLive const&);

		int				m_timeout;
		bool			m_promiscuous;
		std::string		m_device;
#if HAVE_PCAP_DIRECTION_T
		Direction		m_direction;
#endif
		Stats*			mp_stats;

};	// class PcapLive


}	// namespace pcappp


#endif	// __PCAPPP_PCAP_LIVE_H__
