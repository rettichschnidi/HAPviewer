//=======================================================================
// Address.h
//-----------------------------------------------------------------------
// This file is part of the package libpcap++
// Libpcap++ is protected by the GNU General Public License
// Copyright (C) 2008 David Rosal
// For more information visit http://libpcappp.sourceforge.net
//=======================================================================

#ifndef __PCAPPP_ADDRESS_H__
#define __PCAPPP_ADDRESS_H__ 1

#include <pcap++/config.h>

extern "C" {
	#include <sys/socket.h>
	#include <pcap.h>
}


namespace pcappp {


///
/// An Address object represents an address associated to a network interface.
///	@n@n
///	Note that not all the addresses in the list of addresses are necessarily
///	IPv4 or IPv6 addresses: You must check the sa_family member of the struct
///	sockaddr before interpreting the contents of the address
///
class Address
{
	public:

		///
		///	@brief	Creates an Address object as a copy of another
		///
		Address(Address const& addr)
		:	m_addr_t(addr.m_addr_t) { }


		///
		///	@brief	Assigns another Address object's contents to this one
		///
		Address& operator=(Address const& addr)
		{
			if (this != &addr)
				m_addr_t = addr.m_addr_t;
			return *this;
		}


		///
		///	@brief	Destroys an Address object
		///
		virtual ~Address()
		{ }


		///
		///	@brief	Gets the address
		///
		struct sockaddr const* get_address() const
			{ return m_addr_t.addr; }


		///
		///	@brief	Gets the netmask corresponding to the address
		///	@return	A pointer to the netmask, or NULL
		///
		struct sockaddr const* get_netmask() const
			{ return m_addr_t.netmask; }
		
		
		///
		///	@brief	Gets the broadcast address corresponding to the address
		///	@return	A pointer to the broadcast address, or NULL if the device
		///		does not support broadcasts
		///
		struct sockaddr const* get_bcast_address() const
			{ return m_addr_t.broadaddr; }
		
		
		///
		///	@brief	Gets the destination address corresponding to the address
		///	@return	A pointer to the destination address, or NULL if the device
		///		is not a point-to-point one 
		///
		struct sockaddr const* get_dest_address() const
			{ return m_addr_t.dstaddr; }
	
	
		///
		/// @brief	Gets the underlying libpcap C structure
		/// @return	A pointer to the underlying pcap_addr_t
		///
		pcap_addr_t* cobj()
			{ return &m_addr_t; }

		///
		/// @brief	Gets the underlying libpcap C structure
		/// @return	A const pointer to the underlying pcap_addr_t
		///
		pcap_addr_t const* cobj() const
			{ return &m_addr_t; }


	private:

		friend class Device;

		Address(pcap_addr_t const& addr)
		:	m_addr_t(addr) { }
	
		pcap_addr_t	m_addr_t;
	
};	// class Address


}	// namespace pcappp


#endif	// __PCAPPP_ADDRESS_H__
